Only Change P1 state.
Use RyzenTest0.exe to change things.